from game.war import PlaneWar


def main(small_plane_num, medium_plane_num, big_plane_num):
    """ 游戏入口，main方法 """
    war = PlaneWar()
    # 添加小型敌方飞机
    war.add_small_enemies(small_plane_num)
    war.add_medium_enemies(medium_plane_num)
    war.add_big_enemies(big_plane_num)
    war.run_game()


if __name__ == '__main__':
    main(1, 1, 1)
